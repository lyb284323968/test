package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.SysInsureMapper;
import com.ruoyi.system.domain.SysInsure;
import com.ruoyi.system.service.ISysInsureService;

/**
 * 保险Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-03-26
 */
@Service
public class SysInsureServiceImpl implements ISysInsureService 
{
    @Autowired
    private SysInsureMapper sysInsureMapper;

    /**
     * 查询保险
     * 
     * @param insureId 保险主键
     * @return 保险
     */
    @Override
    public SysInsure selectSysInsureByInsureId(Long insureId)
    {
        return sysInsureMapper.selectSysInsureByInsureId(insureId);
    }

    /**
     * 查询保险列表
     * 
     * @param sysInsure 保险
     * @return 保险
     */
    @Override
    public List<SysInsure> selectSysInsureList(SysInsure sysInsure)
    {
        return sysInsureMapper.selectSysInsureList(sysInsure);
    }

    /**
     * 新增保险
     * 
     * @param sysInsure 保险
     * @return 结果
     */
    @Override
    public int insertSysInsure(SysInsure sysInsure)
    {
        return sysInsureMapper.insertSysInsure(sysInsure);
    }

    /**
     * 修改保险
     * 
     * @param sysInsure 保险
     * @return 结果
     */
    @Override
    public int updateSysInsure(SysInsure sysInsure)
    {
        return sysInsureMapper.updateSysInsure(sysInsure);
    }

    /**
     * 批量删除保险
     * 
     * @param insureIds 需要删除的保险主键
     * @return 结果
     */
    @Override
    public int deleteSysInsureByInsureIds(Long[] insureIds)
    {
        return sysInsureMapper.deleteSysInsureByInsureIds(insureIds);
    }

    /**
     * 删除保险信息
     * 
     * @param insureId 保险主键
     * @return 结果
     */
    @Override
    public int deleteSysInsureByInsureId(Long insureId)
    {
        return sysInsureMapper.deleteSysInsureByInsureId(insureId);
    }
}
