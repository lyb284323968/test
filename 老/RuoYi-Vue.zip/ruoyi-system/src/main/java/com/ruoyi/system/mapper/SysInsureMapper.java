package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.SysInsure;
import com.ruoyi.system.domain.vo.EchartsBTVO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 保险Mapper接口
 * 
 * @author ruoyi
 * @date 2023-03-26
 */
@Mapper
public interface SysInsureMapper 
{
    /**
     * 查询保险
     * 
     * @param insureId 保险主键
     * @return 保险
     */
    public SysInsure selectSysInsureByInsureId(Long insureId);

    /**
     * 查询保险列表
     * 
     * @param sysInsure 保险
     * @return 保险集合
     */
    public List<SysInsure> selectSysInsureList(SysInsure sysInsure);

    /**
     * 新增保险
     * 
     * @param sysInsure 保险
     * @return 结果
     */
    public int insertSysInsure(SysInsure sysInsure);

    /**
     * 修改保险
     * 
     * @param sysInsure 保险
     * @return 结果
     */
    public int updateSysInsure(SysInsure sysInsure);

    /**
     * 删除保险
     * 
     * @param insureId 保险主键
     * @return 结果
     */
    public int deleteSysInsureByInsureId(Long insureId);

    /**
     * 批量删除保险
     * 
     * @param insureIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteSysInsureByInsureIds(Long[] insureIds);

    /**
     * 保险类型饼图
     * @return
     */
    List<EchartsBTVO> bingtu();

    /**
     * 保险数量柱形图
     * @return
     */
    List<EchartsBTVO> zhuxing();

    /**
     * 投保金额与赔偿金散点图
     * @return
     */
    List<EchartsBTVO> sandian();
}
