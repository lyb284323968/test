package com.ruoyi.system.mapper;

import com.ruoyi.system.domain.SysFunctionTool;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SysFunctionToolMapper {

    SysFunctionTool selectFunctionToolById(Long id);

    List<SysFunctionTool> selectFunctionToolList(SysFunctionTool functionTool);

    int insertFunctionTool(SysFunctionTool functionTool);

    int updateFunctionTool(SysFunctionTool functionTool);

    int deleteFunctionToolById(Long functionToolId);
}