package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.SysInsure;

/**
 * 保险Service接口
 * 
 * @author ruoyi
 * @date 2023-03-26
 */
public interface ISysInsureService 
{
    /**
     * 查询保险
     * 
     * @param insureId 保险主键
     * @return 保险
     */
    public SysInsure selectSysInsureByInsureId(Long insureId);

    /**
     * 查询保险列表
     * 
     * @param sysInsure 保险
     * @return 保险集合
     */
    public List<SysInsure> selectSysInsureList(SysInsure sysInsure);

    /**
     * 新增保险
     * 
     * @param sysInsure 保险
     * @return 结果
     */
    public int insertSysInsure(SysInsure sysInsure);

    /**
     * 修改保险
     * 
     * @param sysInsure 保险
     * @return 结果
     */
    public int updateSysInsure(SysInsure sysInsure);

    /**
     * 批量删除保险
     * 
     * @param insureIds 需要删除的保险主键集合
     * @return 结果
     */
    public int deleteSysInsureByInsureIds(Long[] insureIds);

    /**
     * 删除保险信息
     * 
     * @param insureId 保险主键
     * @return 结果
     */
    public int deleteSysInsureByInsureId(Long insureId);
}
