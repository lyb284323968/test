package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.SysInsureuser;
import org.apache.ibatis.annotations.Mapper;

/**
 * 保险用户Mapper接口
 * 
 * @author ruoyi
 * @date 2023-03-12
 */
@Mapper
public interface SysInsureuserMapper 
{
    /**
     * 查询保险用户
     * 
     * @param insureuserId 保险用户主键
     * @return 保险用户
     */
    public SysInsureuser selectSysInsureuserByInsureuserId(Long insureuserId);

    /**
     * 查询保险用户列表
     * 
     * @param sysInsureuser 保险用户
     * @return 保险用户集合
     */
    public List<SysInsureuser> selectSysInsureuserList(SysInsureuser sysInsureuser);

    /**
     * 新增保险用户
     * 
     * @param sysInsureuser 保险用户
     * @return 结果
     */
    public int insertSysInsureuser(SysInsureuser sysInsureuser);

    /**
     * 修改保险用户
     * 
     * @param sysInsureuser 保险用户
     * @return 结果
     */
    public int updateSysInsureuser(SysInsureuser sysInsureuser);

    /**
     * 删除保险用户
     * 
     * @param insureuserId 保险用户主键
     * @return 结果
     */
    public int deleteSysInsureuserByInsureuserId(Long insureuserId);

    /**
     * 批量删除保险用户
     * 
     * @param insureuserIds 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteSysInsureuserByInsureuserIds(Long[] insureuserIds);
}
