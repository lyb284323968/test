package com.ruoyi.system.domain.vo;

import java.util.List;

public class EchartsVO {
    /**
     * 横轴数据
     */
    String key;
    /**
     * 纵轴数据
     */
    Integer value;

    List<String> keys;
    List<Integer> values;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public List<String> getKeys() {
        return keys;
    }

    public void setKeys(List<String> keys) {
        this.keys = keys;
    }

    public List<Integer> getValues() {
        return values;
    }

    public void setValues(List<Integer> values) {
        this.values = values;
    }
}
