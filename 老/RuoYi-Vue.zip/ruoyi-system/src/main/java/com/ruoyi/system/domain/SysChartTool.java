package com.ruoyi.system.domain;

import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 图表工具
 * 
 * @author ruoyi
 * @date 2023-04-16
 */
public class SysChartTool extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    private Long id;
    /**
     * 图表名称
     */
    private String chartName;
    /**
     * 图表介绍
     */
    private String chartDescribe;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getChartName() {
        return chartName;
    }

    public void setChartName(String chartName) {
        this.chartName = chartName;
    }

    public String getChartDescribe() {
        return chartDescribe;
    }

    public void setChartDescribe(String chartDescribe) {
        this.chartDescribe = chartDescribe;
    }
}
