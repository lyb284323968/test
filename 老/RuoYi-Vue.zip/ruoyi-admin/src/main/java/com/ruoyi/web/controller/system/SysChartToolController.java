package com.ruoyi.web.controller.system;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.SysChartTool;
import com.ruoyi.system.mapper.SysChartToolMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 图表工具
 * @author ruoyi
 */
@RestController
@RequestMapping("/system/chartTool")
public class SysChartToolController extends BaseController {
    @Autowired
    private SysChartToolMapper chartToolMapper;

    /**
     * 获取图表工具列表
     */
    @PreAuthorize("@ss.hasPermi('system:chartTool:list')")
    @GetMapping("/list")
    public TableDataInfo list(SysChartTool chartTool) {
        startPage();
        List<SysChartTool> list = chartToolMapper.selectChartToolList(chartTool);
        return getDataTable(list);
    }

    /**
     * 根据图表工具编号获取详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:chartTool:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable Long id) {
        return success(chartToolMapper.selectChartToolById(id));
    }

    /**
     * 新增图表工具
     */
    @PreAuthorize("@ss.hasPermi('system:chartTool:add')")
    @Log(title = "图表工具", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody SysChartTool chartTool) {
        chartTool.setCreateBy(getUsername());
        return toAjax(chartToolMapper.insertChartTool(chartTool));
    }

    /**
     * 修改图表工具
     */
    @PreAuthorize("@ss.hasPermi('system:chartTool:edit')")
    @Log(title = "图表工具", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody SysChartTool chartTool) {
        chartTool.setUpdateBy(getUsername());
        return toAjax(chartToolMapper.updateChartTool(chartTool));
    }

    /**
     * 删除图表工具
     */
    @PreAuthorize("@ss.hasPermi('system:chartTool:remove')")
    @Log(title = "图表工具", businessType = BusinessType.DELETE)
    @DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Long id) {
        return toAjax(chartToolMapper.deleteChartToolById(id));
    }
}
