package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 保险用户对象 sys_insureuser
 * 
 * @author ruoyi
 * @date 2023-03-12
 */
public class SysInsureuser extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 保险用户id */
    private Long insureuserId;

    /** 用户id */
    @Excel(name = "用户id")
    private Long userId;

    /** 姓名 */
    @Excel(name = "姓名")
    private String userName;

    /** 性别（0男 1女 2未知） */
    @Excel(name = "性别", readConverterExp = "0=男,1=女,2=未知")
    private String sex;

    /** 年龄 */
    @Excel(name = "年龄")
    private Long age;

    /** 职业 */
    @Excel(name = "职业")
    private String occupation;

    /** 月薪 */
    @Excel(name = "月薪")
    private Long monthlySalary;

    /** 病史 */
    @Excel(name = "病史")
    private String medicalHistory;

    /** 学历 */
    @Excel(name = "学历")
    private String education;

    /** 已婚（0是 1否） */
    @Excel(name = "已婚", readConverterExp = "0=是,1=否")
    private String marry;

    public void setInsureuserId(Long insureuserId) 
    {
        this.insureuserId = insureuserId;
    }

    public Long getInsureuserId() 
    {
        return insureuserId;
    }
    public void setUserId(Long userId) 
    {
        this.userId = userId;
    }

    public Long getUserId() 
    {
        return userId;
    }
    public void setUserName(String userName) 
    {
        this.userName = userName;
    }

    public String getUserName() 
    {
        return userName;
    }
    public void setSex(String sex) 
    {
        this.sex = sex;
    }

    public String getSex() 
    {
        return sex;
    }
    public void setAge(Long age) 
    {
        this.age = age;
    }

    public Long getAge() 
    {
        return age;
    }
    public void setOccupation(String occupation) 
    {
        this.occupation = occupation;
    }

    public String getOccupation() 
    {
        return occupation;
    }
    public void setMonthlySalary(Long monthlySalary) 
    {
        this.monthlySalary = monthlySalary;
    }

    public Long getMonthlySalary() 
    {
        return monthlySalary;
    }
    public void setMedicalHistory(String medicalHistory) 
    {
        this.medicalHistory = medicalHistory;
    }

    public String getMedicalHistory() 
    {
        return medicalHistory;
    }
    public void setEducation(String education) 
    {
        this.education = education;
    }

    public String getEducation() 
    {
        return education;
    }
    public void setMarry(String marry) 
    {
        this.marry = marry;
    }

    public String getMarry() 
    {
        return marry;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("insureuserId", getInsureuserId())
            .append("userId", getUserId())
            .append("userName", getUserName())
            .append("sex", getSex())
            .append("age", getAge())
            .append("occupation", getOccupation())
            .append("monthlySalary", getMonthlySalary())
            .append("medicalHistory", getMedicalHistory())
            .append("education", getEducation())
            .append("marry", getMarry())
            .toString();
    }
}
