package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 保险对象 sys_insure
 * 
 * @author ruoyi
 * @date 2023-03-26
 */
public class SysInsure extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 保险id */
    private Long insureId;

    /** 保险名称 */
    @Excel(name = "保险名称")
    private String insureName;

    /** 保险类型 */
    @Excel(name = "保险类型")
    private String type;

    /** 受众人群 */
    @Excel(name = "受众人群")
    private String people;

    /** 价格 */
    @Excel(name = "价格")
    private Long money;

    /** 赔付价格 */
    @Excel(name = "赔付价格")
    private Long payment;

    /** 保险产品年限 */
    @Excel(name = "保险产品年限")
    private Long insureYear;

    /** 属于哪个保险公司 */
    @Excel(name = "属于哪个保险公司")
    private String company;

    public void setInsureId(Long insureId) 
    {
        this.insureId = insureId;
    }

    public Long getInsureId() 
    {
        return insureId;
    }
    public void setInsureName(String insureName) 
    {
        this.insureName = insureName;
    }

    public String getInsureName() 
    {
        return insureName;
    }
    public void setType(String type) 
    {
        this.type = type;
    }

    public String getType() 
    {
        return type;
    }
    public void setPeople(String people) 
    {
        this.people = people;
    }

    public String getPeople() 
    {
        return people;
    }
    public void setMoney(Long money) 
    {
        this.money = money;
    }

    public Long getMoney() 
    {
        return money;
    }
    public void setPayment(Long payment) 
    {
        this.payment = payment;
    }

    public Long getPayment() 
    {
        return payment;
    }
    public void setInsureYear(Long insureYear) 
    {
        this.insureYear = insureYear;
    }

    public Long getInsureYear() 
    {
        return insureYear;
    }
    public void setCompany(String company) 
    {
        this.company = company;
    }

    public String getCompany() 
    {
        return company;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("insureId", getInsureId())
            .append("insureName", getInsureName())
            .append("type", getType())
            .append("people", getPeople())
            .append("money", getMoney())
            .append("payment", getPayment())
            .append("insureYear", getInsureYear())
            .append("company", getCompany())
            .toString();
    }
}
