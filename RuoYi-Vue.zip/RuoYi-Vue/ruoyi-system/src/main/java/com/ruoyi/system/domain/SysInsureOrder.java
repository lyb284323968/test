package com.ruoyi.system.domain;

import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import java.util.Date;

/**
 * 保险订单表 sys_insure_order
 */
public class SysInsureOrder extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 保险订单id */
    private Long id;

    /** 保险id */
    private Long SysInsureId;

    /** 用户id */
    private Long SysUserId;

    /** 创建时间 */
    private Date createDate;

    /** 更新时间 */
    private Date updateDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSysInsureId() {
        return SysInsureId;
    }

    public void setSysInsureId(Long sysInsureId) {
        SysInsureId = sysInsureId;
    }

    public Long getSysUserId() {
        return SysUserId;
    }

    public void setSysUserId(Long sysUserId) {
        SysUserId = sysUserId;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }
}
