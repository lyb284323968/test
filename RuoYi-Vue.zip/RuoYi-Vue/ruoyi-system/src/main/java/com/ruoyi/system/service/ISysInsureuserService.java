package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.SysInsureuser;

/**
 * 保险用户Service接口
 * 
 * @author ruoyi
 * @date 2023-03-12
 */
public interface ISysInsureuserService 
{
    /**
     * 查询保险用户
     * 
     * @param insureuserId 保险用户主键
     * @return 保险用户
     */
    public SysInsureuser selectSysInsureuserByInsureuserId(Long insureuserId);

    /**
     * 查询保险用户列表
     * 
     * @param sysInsureuser 保险用户
     * @return 保险用户集合
     */
    public List<SysInsureuser> selectSysInsureuserList(SysInsureuser sysInsureuser);

    /**
     * 新增保险用户
     * 
     * @param sysInsureuser 保险用户
     * @return 结果
     */
    public int insertSysInsureuser(SysInsureuser sysInsureuser);

    /**
     * 修改保险用户
     * 
     * @param sysInsureuser 保险用户
     * @return 结果
     */
    public int updateSysInsureuser(SysInsureuser sysInsureuser);

    /**
     * 批量删除保险用户
     * 
     * @param insureuserIds 需要删除的保险用户主键集合
     * @return 结果
     */
    public int deleteSysInsureuserByInsureuserIds(Long[] insureuserIds);

    /**
     * 删除保险用户信息
     * 
     * @param insureuserId 保险用户主键
     * @return 结果
     */
    public int deleteSysInsureuserByInsureuserId(Long insureuserId);
}
