package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.SysInsureuserMapper;
import com.ruoyi.system.domain.SysInsureuser;
import com.ruoyi.system.service.ISysInsureuserService;

/**
 * 保险用户Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-03-12
 */
@Service
public class SysInsureuserServiceImpl implements ISysInsureuserService 
{
    @Autowired
    private SysInsureuserMapper sysInsureuserMapper;

    /**
     * 查询保险用户
     * 
     * @param insureuserId 保险用户主键
     * @return 保险用户
     */
    @Override
    public SysInsureuser selectSysInsureuserByInsureuserId(Long insureuserId)
    {
        return sysInsureuserMapper.selectSysInsureuserByInsureuserId(insureuserId);
    }

    /**
     * 查询保险用户列表
     * 
     * @param sysInsureuser 保险用户
     * @return 保险用户
     */
    @Override
    public List<SysInsureuser> selectSysInsureuserList(SysInsureuser sysInsureuser)
    {
        return sysInsureuserMapper.selectSysInsureuserList(sysInsureuser);
    }

    /**
     * 新增保险用户
     * 
     * @param sysInsureuser 保险用户
     * @return 结果
     */
    @Override
    public int insertSysInsureuser(SysInsureuser sysInsureuser)
    {
        return sysInsureuserMapper.insertSysInsureuser(sysInsureuser);
    }

    /**
     * 修改保险用户
     * 
     * @param sysInsureuser 保险用户
     * @return 结果
     */
    @Override
    public int updateSysInsureuser(SysInsureuser sysInsureuser)
    {
        return sysInsureuserMapper.updateSysInsureuser(sysInsureuser);
    }

    /**
     * 批量删除保险用户
     * 
     * @param insureuserIds 需要删除的保险用户主键
     * @return 结果
     */
    @Override
    public int deleteSysInsureuserByInsureuserIds(Long[] insureuserIds)
    {
        return sysInsureuserMapper.deleteSysInsureuserByInsureuserIds(insureuserIds);
    }

    /**
     * 删除保险用户信息
     * 
     * @param insureuserId 保险用户主键
     * @return 结果
     */
    @Override
    public int deleteSysInsureuserByInsureuserId(Long insureuserId)
    {
        return sysInsureuserMapper.deleteSysInsureuserByInsureuserId(insureuserId);
    }
}
