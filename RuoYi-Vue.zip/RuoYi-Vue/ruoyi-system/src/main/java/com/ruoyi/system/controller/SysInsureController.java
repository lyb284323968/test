package com.ruoyi.system.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.system.domain.vo.EchartsBTVO;
import com.ruoyi.system.mapper.SysInsureMapper;
import com.ruoyi.system.mapper.SysInsureOrderMapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.SysInsure;
import com.ruoyi.system.service.ISysInsureService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 保险Controller
 *
 * @author ruoyi
 * @date 2023-03-26
 */
@RestController
@RequestMapping("/system/insure")
public class SysInsureController extends BaseController {
    @Autowired
    private ISysInsureService sysInsureService;

    @Autowired
    private SysInsureMapper sysInsureMapper;

    @Autowired
    private SysInsureOrderMapper sysInsureOrderMapper;

    /**
     * 查询保险列表
     */
    @PreAuthorize("@ss.hasPermi('system:insure:list')")
    @GetMapping("/list")
    public TableDataInfo list(SysInsure sysInsure) {
        startPage();
        List<SysInsure> list = sysInsureService.selectSysInsureList(sysInsure);
        return getDataTable(list);
    }

    /**
     * 导出保险列表
     */
    @PreAuthorize("@ss.hasPermi('system:insure:export')")
    @Log(title = "保险", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, SysInsure sysInsure) {
        List<SysInsure> list = sysInsureService.selectSysInsureList(sysInsure);
        ExcelUtil<SysInsure> util = new ExcelUtil<SysInsure>(SysInsure.class);
        util.exportExcel(response, list, "保险数据");
    }

    /**
     * 获取保险详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:insure:query')")
    @GetMapping(value = "/{insureId}")
    public AjaxResult getInfo(@PathVariable("insureId") Long insureId) {
        return success(sysInsureService.selectSysInsureByInsureId(insureId));
    }

    /**
     * 新增保险
     */
    @PreAuthorize("@ss.hasPermi('system:insure:add')")
    @Log(title = "保险", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysInsure sysInsure) {
        return toAjax(sysInsureService.insertSysInsure(sysInsure));
    }

    /**
     * 修改保险
     */
    @PreAuthorize("@ss.hasPermi('system:insure:edit')")
    @Log(title = "保险", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysInsure sysInsure) {
        return toAjax(sysInsureService.updateSysInsure(sysInsure));
    }

    /**
     * 删除保险
     */
    @PreAuthorize("@ss.hasPermi('system:insure:remove')")
    @Log(title = "保险", businessType = BusinessType.DELETE)
    @DeleteMapping("/{insureIds}")
    public AjaxResult remove(@PathVariable Long[] insureIds) {
        return toAjax(sysInsureService.deleteSysInsureByInsureIds(insureIds));
    }

    /**
     * 柱形图数据
     */
    @PreAuthorize("@ss.hasPermi('system:insure:list')")
    @GetMapping("/echarts/zhuxing")
    public Map<String, Object> zhuxing() {
        ArrayList<Integer> integers = new ArrayList<>();
        ArrayList<String> strings = new ArrayList<>();
        for (EchartsBTVO echartsBTVO : sysInsureMapper.zhuxing()) {
            integers.add(echartsBTVO.getValue());
            strings.add(echartsBTVO.getName());
        }
        Map<String, Object> map = new HashMap<>();
        map.put("value", integers);
        map.put("name", strings);
        return map;
    }

    /**
     * 饼图数据
     */
    @PreAuthorize("@ss.hasPermi('system:insure:list')")
    @GetMapping("/echarts/bingtu")
    public List<EchartsBTVO> bingtu() {
        List<EchartsBTVO> bingtu = sysInsureMapper.bingtu();
        return bingtu;
    }

    /**
     * 散点图数据
     */
    @PreAuthorize("@ss.hasPermi('system:insure:list')")
    @GetMapping("/echarts/sandian")
    public List<EchartsBTVO> sandian() {
        List<EchartsBTVO> sandian = sysInsureMapper.sandian();
        return sandian;
    }

    /**
     * 漏斗图数据
     */
    @PreAuthorize("@ss.hasPermi('system:insure:list')")
    @GetMapping("/echarts/loudou")
    public Map<String, Object> loudou() {
        List<EchartsBTVO> loudou = sysInsureOrderMapper.loudou();
        ArrayList<String> strings = new ArrayList<>();
        for (EchartsBTVO echartsBTVO : loudou) {
            strings.add(echartsBTVO.getName());
        }
        Map<String, Object> map = new HashMap<>();
        map.put("value", loudou);
        map.put("name", strings);
        return map;
    }
}