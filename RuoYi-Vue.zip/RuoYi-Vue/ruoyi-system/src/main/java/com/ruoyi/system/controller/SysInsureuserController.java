package com.ruoyi.system.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.SysInsureuser;
import com.ruoyi.system.service.ISysInsureuserService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 保险用户Controller
 * 
 * @author ruoyi
 * @date 2023-03-12
 */
@RestController
@RequestMapping("/system/insureuser")
public class SysInsureuserController extends BaseController
{
    @Autowired
    private ISysInsureuserService sysInsureuserService;

    /**
     * 查询保险用户列表
     */
    @PreAuthorize("@ss.hasPermi('system:insureuser:list')")
    @GetMapping("/list")
    public TableDataInfo list(SysInsureuser sysInsureuser)
    {
        startPage();
        List<SysInsureuser> list = sysInsureuserService.selectSysInsureuserList(sysInsureuser);
        return getDataTable(list);
    }

    /**
     * 导出保险用户列表
     */
    @PreAuthorize("@ss.hasPermi('system:insureuser:export')")
    @Log(title = "保险用户", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, SysInsureuser sysInsureuser)
    {
        List<SysInsureuser> list = sysInsureuserService.selectSysInsureuserList(sysInsureuser);
        ExcelUtil<SysInsureuser> util = new ExcelUtil<SysInsureuser>(SysInsureuser.class);
        util.exportExcel(response, list, "保险用户数据");
    }

    /**
     * 获取保险用户详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:insureuser:query')")
    @GetMapping(value = "/{insureuserId}")
    public AjaxResult getInfo(@PathVariable("insureuserId") Long insureuserId)
    {
        return success(sysInsureuserService.selectSysInsureuserByInsureuserId(insureuserId));
    }

    /**
     * 新增保险用户
     */
    @PreAuthorize("@ss.hasPermi('system:insureuser:add')")
    @Log(title = "保险用户", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysInsureuser sysInsureuser)
    {
        return toAjax(sysInsureuserService.insertSysInsureuser(sysInsureuser));
    }

    /**
     * 修改保险用户
     */
    @PreAuthorize("@ss.hasPermi('system:insureuser:edit')")
    @Log(title = "保险用户", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysInsureuser sysInsureuser)
    {
        return toAjax(sysInsureuserService.updateSysInsureuser(sysInsureuser));
    }

    /**
     * 删除保险用户
     */
    @PreAuthorize("@ss.hasPermi('system:insureuser:remove')")
    @Log(title = "保险用户", businessType = BusinessType.DELETE)
	@DeleteMapping("/{insureuserIds}")
    public AjaxResult remove(@PathVariable Long[] insureuserIds)
    {
        return toAjax(sysInsureuserService.deleteSysInsureuserByInsureuserIds(insureuserIds));
    }
}
