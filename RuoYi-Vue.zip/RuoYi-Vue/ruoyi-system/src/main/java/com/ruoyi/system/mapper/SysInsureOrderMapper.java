package com.ruoyi.system.mapper;


import com.ruoyi.system.domain.vo.EchartsBTVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;


/**
 * 保险Mapper接口
 *
 * @author ruoyi
 * @date 2023-03-26
 */
@Mapper
public interface SysInsureOrderMapper {
    /**
     * 保险推荐:漏斗图排行
     * @return
     */
    List<EchartsBTVO> loudou();
}
