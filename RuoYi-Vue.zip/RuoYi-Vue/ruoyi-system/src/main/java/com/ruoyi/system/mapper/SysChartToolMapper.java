package com.ruoyi.system.mapper;

import com.ruoyi.system.domain.SysChartTool;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SysChartToolMapper {

    SysChartTool selectChartToolById(Long id);

    List<SysChartTool> selectChartToolList(SysChartTool chartTool);

    int insertChartTool(SysChartTool chartTool);

    int updateChartTool(SysChartTool chartTool);

    int deleteChartToolById(Long chartToolId);
}