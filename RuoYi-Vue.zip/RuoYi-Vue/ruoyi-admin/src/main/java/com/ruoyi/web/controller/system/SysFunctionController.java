package com.ruoyi.web.controller.system;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.SysFunctionTool;
import com.ruoyi.system.mapper.SysFunctionToolMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 函数工具
 * @author ruoyi
 */
@RestController
@RequestMapping("/system/functionTool")
public class SysFunctionController extends BaseController {
    @Autowired
    private SysFunctionToolMapper functionToolMapper;

    /**
     * 获取函数工具列表
     */
    @PreAuthorize("@ss.hasPermi('system:functionTool:list')")
    @GetMapping("/list")
    public TableDataInfo list(SysFunctionTool functionTool) {
        startPage();
        List<SysFunctionTool> list = functionToolMapper.selectFunctionToolList(functionTool);
        return getDataTable(list);
    }

    /**
     * 根据函数工具编号获取详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:functionTool:list')")
    @GetMapping(value = "query/{id}")
    public AjaxResult getInfo(@PathVariable Long id) {
        return success(functionToolMapper.selectFunctionToolById(id));
    }

    /**
     * 新增函数工具
     */
    @PreAuthorize("@ss.hasPermi('system:functionTool:list')")
    @Log(title = "函数工具", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@Validated @RequestBody SysFunctionTool functionTool) {
        functionTool.setCreateBy(getUsername());
        return toAjax(functionToolMapper.insertFunctionTool(functionTool));
    }

    /**
     * 修改函数工具
     */
    @PreAuthorize("@ss.hasPermi('system:functionTool:list')")
    @Log(title = "函数工具", businessType = BusinessType.UPDATE)
    @PostMapping("/update")
    public AjaxResult edit(@Validated @RequestBody SysFunctionTool functionTool) {
        functionTool.setUpdateBy(getUsername());
        return toAjax(functionToolMapper.updateFunctionTool(functionTool));
    }

    /**
     * 删除函数工具
     */
    @PreAuthorize("@ss.hasPermi('system:functionTool:list')")
    @Log(title = "函数工具", businessType = BusinessType.DELETE)
    @GetMapping("delete/{id}")
    public AjaxResult remove(@PathVariable Long id) {
        return toAjax(functionToolMapper.deleteFunctionToolById(id));
    }
}
